<?php

if(isset($_GET['down']) && $_GET['down'] == 1)
{
    down();
}
function down(){
    require_once './phpqrcode.php';
    $url = 'http://baidu.com/?d='.time();
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="'.time().mt_rand(100,999).'.png"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    QRcode::png($url,false);
}
?>
<a href="index.php?down=1">下载</a>





